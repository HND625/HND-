package com.harappanewsdarpan.hnd

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.webkit.WebSettings
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val home = "https://harappanewsdarpa.com/"
    // Update these paths if the website's final reporter/e-paper URLs differ.
    private val reporter = "https://harappanewsdarpa.com/reporter-dashboard/"
    private val epaper = "https://harappanewsdarpa.com/e-paper/"
    private val videos = "https://www.youtube.com/results?search_query=HARAPPA+NEWS+DARPAN"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 29, 56)
        window.navigationBarColor = Color.rgb(16, 29, 56)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val header = TextView(this).apply {
            text = "HND  |  HARAPPA NEWS DARPAN\nखबर सच तक"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(16, 29, 56))
            gravity = Gravity.CENTER
            setPadding(12, 18, 12, 18)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                return if (url.host?.endsWith("harappanewsdarpa.com") == true) {
                    false
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                }
            }
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(16, 29, 56))
        }
        addNav(nav, "होम") { web.loadUrl(home) }
        addNav(nav, "रिपोर्टर") { web.loadUrl(reporter) }
        addNav(nav, "ई-पेपर") { web.loadUrl(epaper) }
        addNav(nav, "वीडियो") { web.loadUrl(videos) }
        root.addView(nav, LinearLayout.LayoutParams(-1, 56))

        setContentView(root)
        web.loadUrl(home)
    }

    private fun addNav(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(16, 29, 56))
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(0, -1, 1f))
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
